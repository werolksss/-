﻿using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace Practice01
{
    internal class Program
    {
        // Подключаем функции Windows API из user32.dll

        [DllImport("user32.dll", CharSet = CharSet.Unicode,
            EntryPoint = "MessageBoxW", ExactSpelling = true)]
        private static extern int MessageBox(
            IntPtr hWnd,
            string text,
            string caption,
            uint type);

        [DllImport("user32.dll", CharSet = CharSet.Unicode,
            EntryPoint = "FindWindowW", ExactSpelling = true)]
        private static extern IntPtr FindWindow(
            string className,
            string? windowName);

        // Для отправки команды закрытия
        [DllImport("user32.dll", CharSet = CharSet.Unicode,
            EntryPoint = "SendMessageW", ExactSpelling = true)]
        private static extern IntPtr SendMessage(
            IntPtr hWnd,
            uint message,
            IntPtr wParam,
            IntPtr lParam);

        // Для отправки текста заголовка
        [DllImport("user32.dll", CharSet = CharSet.Unicode,
            EntryPoint = "SendMessageW", ExactSpelling = true)]
        private static extern IntPtr SendMessage(
            IntPtr hWnd,
            uint message,
            IntPtr wParam,
            string lParam);

        [DllImport("user32.dll", CharSet = CharSet.Unicode,
            EntryPoint = "GetWindowTextW", ExactSpelling = true)]
        private static extern int GetWindowText(
            IntPtr hWnd,
            StringBuilder text,
            int maxCount);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool IsWindow(IntPtr hWnd);

        private const uint WM_CLOSE = 0x0010;
        private const uint WM_SETTEXT = 0x000C;

        private const uint MB_OK = 0x00000000;
        private const uint MB_YESNO = 0x00000004;
        private const uint MB_YESNOCANCEL = 0x00000003;
        private const uint MB_ICONQUESTION = 0x00000020;
        private const uint MB_ICONINFORMATION = 0x00000040;

        private const int IDYES = 6;
        private const int IDNO = 7;
        private const int IDCANCEL = 2;

        static void Main()
        {
            Console.OutputEncoding = Encoding.UTF8;

            if (!OperatingSystem.IsWindows())
            {
                Console.WriteLine("Эта программа предназначена для Windows.");
                return;
            }

            while (true)
            {
                Console.Clear();
                Console.WriteLine("Практическая работа №1");
                Console.WriteLine("Использование унаследованного кода\n");

                Console.WriteLine("1. Сообщение Hello, World!");
                Console.WriteLine("2. Угадывание числа");
                Console.WriteLine("3. Закрытие Блокнота");
                Console.WriteLine("4. Время в заголовке Блокнота");
                Console.WriteLine("0. Выход");

                Console.Write("\nВыберите задание: ");
                string choice = Console.ReadLine() ?? "";

                if (choice == "0")
                    return;

                Console.Clear();

                switch (choice)
                {
                    case "1":
                        Zadanie1();
                        break;

                    case "2":
                        Zadanie2();
                        break;

                    case "3":
                        Zadanie3();
                        break;

                    case "4":
                        Zadanie4();
                        break;

                    default:
                        Console.WriteLine("Такого пункта нет.");
                        break;
                }

                Console.WriteLine("\nНажмите любую клавишу для возврата в меню.");
                Console.ReadKey(true);
            }
        }

        static void Zadanie1()
        {
            Console.WriteLine("Задание 1. MessageBox");

            MessageBox(
                IntPtr.Zero,
                "Hello, World!",
                "Задание 1",
                MB_OK | MB_ICONINFORMATION);

            Console.WriteLine("Сообщение показано.");
        }

        static void Zadanie2()
        {
            Console.WriteLine("Задание 2. Компьютер угадывает число");

            bool repeat;

            do
            {
                int left = 0;
                int right = 100;
                int attempts = 0;
                bool guessed = false;

                MessageBox(
                    IntPtr.Zero,
                    "Загадайте целое число от 0 до 100.\n" +
                    "Я попробую его угадать.",
                    "Начало игры",
                    MB_OK | MB_ICONINFORMATION);

                while (left <= right)
                {
                    int number = left + (right - left) / 2;
                    attempts++;

                    int answer = MessageBox(
                        IntPtr.Zero,
                        $"Ваше число: {number}?\n\n" +
                        "Да — число угадано.\n" +
                        "Нет — ваше число больше.\n" +
                        "Отмена — ваше число меньше.",
                        $"Попытка №{attempts}",
                        MB_YESNOCANCEL | MB_ICONQUESTION);

                    if (answer == IDYES)
                    {
                        MessageBox(
                            IntPtr.Zero,
                            $"Угадано число {number}!\n" +
                            $"Количество попыток: {attempts}",
                            "Результат",
                            MB_OK | MB_ICONINFORMATION);

                        guessed = true;
                        break;
                    }
                    else if (answer == IDNO)
                    {
                        left = number + 1;
                    }
                    else if (answer == IDCANCEL)
                    {
                        right = number - 1;
                    }
                    else
                    {
                        Console.WriteLine("Не удалось получить ответ.");
                        return;
                    }
                }

                if (!guessed)
                {
                    MessageBox(
                        IntPtr.Zero,
                        "Ответы противоречат друг другу.\n" +
                        "В указанном диапазоне не осталось чисел.",
                        "Результат",
                        MB_OK | MB_ICONINFORMATION);
                }

                repeat = MessageBox(
                    IntPtr.Zero,
                    "Хотите сыграть ещё раз?",
                    "Повторная игра",
                    MB_YESNO | MB_ICONQUESTION) == IDYES;

            } while (repeat);

            Console.WriteLine("Игра завершена.");
        }

        static void Zadanie3()
        {
            Console.WriteLine("Задание 3. Закрытие Блокнота\n");

            // Ищем окно по имени класса, независимо от заголовка
            IntPtr window = FindWindow("Notepad", null);

            if (window == IntPtr.Zero)
            {
                Console.WriteLine("Окно Блокнота не найдено.");
                Console.WriteLine("Откройте Блокнот и повторите задание.");
                return;
            }

            Console.WriteLine("Окно Блокнота найдено.");

            // Отправляем обычный запрос на закрытие окна
            SendMessage(window, WM_CLOSE, IntPtr.Zero, IntPtr.Zero);

            Console.WriteLine("Окну отправлена команда закрытия.");
            Console.WriteLine(
                "Если есть несохранённый текст, Блокнот может запросить сохранение.");
        }

        static void Zadanie4()
        {
            Console.WriteLine("Задание 4. Время в заголовке Блокнота\n");

            IntPtr window = FindWindow("Notepad", null);

            if (window == IntPtr.Zero)
            {
                Console.WriteLine("Окно Блокнота не найдено.");
                Console.WriteLine("Откройте Блокнот и повторите задание.");
                return;
            }

            // Запоминаем исходный заголовок
            StringBuilder title = new StringBuilder(1024);
            GetWindowText(window, title, title.Capacity);
            string originalTitle = title.ToString();

            Console.WriteLine("Окно Блокнота найдено.");
            Console.WriteLine("Время обновляется каждую секунду.");
            Console.WriteLine(
                "Для остановки вернитесь в эту консоль и нажмите Enter.\n");

            try
            {
                while (IsWindow(window))
                {
                    if (Console.KeyAvailable)
                    {
                        ConsoleKeyInfo key = Console.ReadKey(true);

                        if (key.Key == ConsoleKey.Enter)
                            break;
                    }

                    string time = DateTime.Now.ToString("HH:mm:ss");

                    SendMessage(
                        window,
                        WM_SETTEXT,
                        IntPtr.Zero,
                        "Блокнот — " + time);

                    Console.Write("\rТекущее время: " + time);

                    Thread.Sleep(1000);
                }
            }
            finally
            {
                // Возвращаем исходный заголовок, если окно ещё открыто
                if (IsWindow(window))
                {
                    SendMessage(
                        window,
                        WM_SETTEXT,
                        IntPtr.Zero,
                        originalTitle);
                }
            }

            Console.WriteLine("\nОбновление времени остановлено.");
        }
    }
}